/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.sample.libray.metamodel.libray.Item;
import org.rm2pt.sample.libray.metamodel.libray.Library;
import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Membership;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Library</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl#getStudents <em>Students</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl#getMembership <em>Membership</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl#getBorrowableitem <em>Borrowableitem</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl#getLibrarian <em>Librarian</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl#getAdministrator <em>Administrator</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LibraryImpl extends MinimalEObjectImpl.Container implements Library {
	/**
	 * The default value of the '{@link #getStudents() <em>Students</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStudents()
	 * @generated
	 * @ordered
	 */
	protected static final String STUDENTS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStudents() <em>Students</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStudents()
	 * @generated
	 * @ordered
	 */
	protected String students = STUDENTS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMembership() <em>Membership</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMembership()
	 * @generated
	 * @ordered
	 */
	protected EList<Membership> membership;

	/**
	 * The cached value of the '{@link #getBorrowableitem() <em>Borrowableitem</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBorrowableitem()
	 * @generated
	 * @ordered
	 */
	protected EList<Item> borrowableitem;

	/**
	 * The default value of the '{@link #getLibrarian() <em>Librarian</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibrarian()
	 * @generated
	 * @ordered
	 */
	protected static final String LIBRARIAN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLibrarian() <em>Librarian</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibrarian()
	 * @generated
	 * @ordered
	 */
	protected String librarian = LIBRARIAN_EDEFAULT;

	/**
	 * The default value of the '{@link #getAdministrator() <em>Administrator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdministrator()
	 * @generated
	 * @ordered
	 */
	protected static final String ADMINISTRATOR_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAdministrator() <em>Administrator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAdministrator()
	 * @generated
	 * @ordered
	 */
	protected String administrator = ADMINISTRATOR_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LibraryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.LIBRARY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStudents() {
		return students;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStudents(String newStudents) {
		String oldStudents = students;
		students = newStudents;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.LIBRARY__STUDENTS, oldStudents,
					students));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Membership> getMembership() {
		if (membership == null) {
			membership = new EObjectContainmentEList<Membership>(Membership.class, this,
					LibrayPackage.LIBRARY__MEMBERSHIP);
		}
		return membership;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Item> getBorrowableitem() {
		if (borrowableitem == null) {
			borrowableitem = new EObjectContainmentEList<Item>(Item.class, this, LibrayPackage.LIBRARY__BORROWABLEITEM);
		}
		return borrowableitem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLibrarian() {
		return librarian;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLibrarian(String newLibrarian) {
		String oldLibrarian = librarian;
		librarian = newLibrarian;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.LIBRARY__LIBRARIAN, oldLibrarian,
					librarian));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAdministrator() {
		return administrator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAdministrator(String newAdministrator) {
		String oldAdministrator = administrator;
		administrator = newAdministrator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.LIBRARY__ADMINISTRATOR,
					oldAdministrator, administrator));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LibrayPackage.LIBRARY__MEMBERSHIP:
			return ((InternalEList<?>) getMembership()).basicRemove(otherEnd, msgs);
		case LibrayPackage.LIBRARY__BORROWABLEITEM:
			return ((InternalEList<?>) getBorrowableitem()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.LIBRARY__STUDENTS:
			return getStudents();
		case LibrayPackage.LIBRARY__MEMBERSHIP:
			return getMembership();
		case LibrayPackage.LIBRARY__BORROWABLEITEM:
			return getBorrowableitem();
		case LibrayPackage.LIBRARY__LIBRARIAN:
			return getLibrarian();
		case LibrayPackage.LIBRARY__ADMINISTRATOR:
			return getAdministrator();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.LIBRARY__STUDENTS:
			setStudents((String) newValue);
			return;
		case LibrayPackage.LIBRARY__MEMBERSHIP:
			getMembership().clear();
			getMembership().addAll((Collection<? extends Membership>) newValue);
			return;
		case LibrayPackage.LIBRARY__BORROWABLEITEM:
			getBorrowableitem().clear();
			getBorrowableitem().addAll((Collection<? extends Item>) newValue);
			return;
		case LibrayPackage.LIBRARY__LIBRARIAN:
			setLibrarian((String) newValue);
			return;
		case LibrayPackage.LIBRARY__ADMINISTRATOR:
			setAdministrator((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.LIBRARY__STUDENTS:
			setStudents(STUDENTS_EDEFAULT);
			return;
		case LibrayPackage.LIBRARY__MEMBERSHIP:
			getMembership().clear();
			return;
		case LibrayPackage.LIBRARY__BORROWABLEITEM:
			getBorrowableitem().clear();
			return;
		case LibrayPackage.LIBRARY__LIBRARIAN:
			setLibrarian(LIBRARIAN_EDEFAULT);
			return;
		case LibrayPackage.LIBRARY__ADMINISTRATOR:
			setAdministrator(ADMINISTRATOR_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.LIBRARY__STUDENTS:
			return STUDENTS_EDEFAULT == null ? students != null : !STUDENTS_EDEFAULT.equals(students);
		case LibrayPackage.LIBRARY__MEMBERSHIP:
			return membership != null && !membership.isEmpty();
		case LibrayPackage.LIBRARY__BORROWABLEITEM:
			return borrowableitem != null && !borrowableitem.isEmpty();
		case LibrayPackage.LIBRARY__LIBRARIAN:
			return LIBRARIAN_EDEFAULT == null ? librarian != null : !LIBRARIAN_EDEFAULT.equals(librarian);
		case LibrayPackage.LIBRARY__ADMINISTRATOR:
			return ADMINISTRATOR_EDEFAULT == null ? administrator != null
					: !ADMINISTRATOR_EDEFAULT.equals(administrator);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (students: ");
		result.append(students);
		result.append(", librarian: ");
		result.append(librarian);
		result.append(", administrator: ");
		result.append(administrator);
		result.append(')');
		return result.toString();
	}

} //LibraryImpl
