/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayFactory
 * @model kind="package"
 * @generated
 */
public interface LibrayPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "libray";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/libray";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "libray";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LibrayPackage eINSTANCE = org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl <em>Library</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getLibrary()
	 * @generated
	 */
	int LIBRARY = 0;

	/**
	 * The feature id for the '<em><b>Students</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__STUDENTS = 0;

	/**
	 * The feature id for the '<em><b>Membership</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__MEMBERSHIP = 1;

	/**
	 * The feature id for the '<em><b>Borrowableitem</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__BORROWABLEITEM = 2;

	/**
	 * The feature id for the '<em><b>Librarian</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__LIBRARIAN = 3;

	/**
	 * The feature id for the '<em><b>Administrator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY__ADMINISTRATOR = 4;

	/**
	 * The number of structural features of the '<em>Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIBRARY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl <em>Membership</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembership()
	 * @generated
	 */
	int MEMBERSHIP = 1;

	/**
	 * The feature id for the '<em><b>Members Details</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP__MEMBERS_DETAILS = 0;

	/**
	 * The feature id for the '<em><b>Bannedmembers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP__BANNEDMEMBERS = 1;

	/**
	 * The feature id for the '<em><b>Members</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP__MEMBERS = 2;

	/**
	 * The number of structural features of the '<em>Membership</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Membership</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERSHIP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl <em>Item</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItem()
	 * @generated
	 */
	int ITEM = 2;

	/**
	 * The feature id for the '<em><b>Booksavailable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__BOOKSAVAILABLE = 0;

	/**
	 * The feature id for the '<em><b>Magazines Availble</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__MAGAZINES_AVAILBLE = 1;

	/**
	 * The feature id for the '<em><b>Magazines</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__MAGAZINES = 2;

	/**
	 * The feature id for the '<em><b>Books</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__BOOKS = 3;

	/**
	 * The feature id for the '<em><b>Banneditems</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM__BANNEDITEMS = 4;

	/**
	 * The number of structural features of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Item</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ITEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl <em>Banned Items</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getBannedItems()
	 * @generated
	 */
	int BANNED_ITEMS = 3;

	/**
	 * The feature id for the '<em><b>Item</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS__ITEM = 0;

	/**
	 * The number of structural features of the '<em>Banned Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Banned Items</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BANNED_ITEMS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl <em>Magazines</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMagazines()
	 * @generated
	 */
	int MAGAZINES = 4;

	/**
	 * The feature id for the '<em><b>Item</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES__ITEM = 0;

	/**
	 * The number of structural features of the '<em>Magazines</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Magazines</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MAGAZINES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl <em>books</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getbooks()
	 * @generated
	 */
	int BOOKS = 5;

	/**
	 * The feature id for the '<em><b>Item</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS__ITEM = 0;

	/**
	 * The number of structural features of the '<em>books</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>books</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOOKS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl <em>Members</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl
	 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembers()
	 * @generated
	 */
	int MEMBERS = 6;

	/**
	 * The number of structural features of the '<em>Members</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Members</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMBERS_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Library <em>Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Library</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library
	 * @generated
	 */
	EClass getLibrary();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getStudents <em>Students</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Students</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getStudents()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Students();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getMembership <em>Membership</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Membership</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getMembership()
	 * @see #getLibrary()
	 * @generated
	 */
	EReference getLibrary_Membership();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getBorrowableitem <em>Borrowableitem</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Borrowableitem</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getBorrowableitem()
	 * @see #getLibrary()
	 * @generated
	 */
	EReference getLibrary_Borrowableitem();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian <em>Librarian</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Librarian</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Librarian();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator <em>Administrator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Administrator</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator()
	 * @see #getLibrary()
	 * @generated
	 */
	EAttribute getLibrary_Administrator();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Membership <em>Membership</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Membership</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership
	 * @generated
	 */
	EClass getMembership();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getMembersDetails <em>Members Details</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Members Details</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership#getMembersDetails()
	 * @see #getMembership()
	 * @generated
	 */
	EReference getMembership_MembersDetails();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bannedmembers</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers()
	 * @see #getMembership()
	 * @generated
	 */
	EAttribute getMembership_Bannedmembers();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getMembers <em>Members</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Members</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Membership#getMembers()
	 * @see #getMembership()
	 * @generated
	 */
	EReference getMembership_Members();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Item <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item
	 * @generated
	 */
	EClass getItem();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable <em>Booksavailable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Booksavailable</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getBooksavailable()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_Booksavailable();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble <em>Magazines Availble</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Magazines Availble</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getMagazinesAvailble()
	 * @see #getItem()
	 * @generated
	 */
	EAttribute getItem_MagazinesAvailble();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getMagazines <em>Magazines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Magazines</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getMagazines()
	 * @see #getItem()
	 * @generated
	 */
	EReference getItem_Magazines();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBooks <em>Books</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Books</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getBooks()
	 * @see #getItem()
	 * @generated
	 */
	EReference getItem_Books();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.libray.metamodel.libray.Item#getBanneditems <em>Banneditems</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Banneditems</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Item#getBanneditems()
	 * @see #getItem()
	 * @generated
	 */
	EReference getItem_Banneditems();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems <em>Banned Items</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Banned Items</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.BannedItems
	 * @generated
	 */
	EClass getBannedItems();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.BannedItems#getItem <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.BannedItems#getItem()
	 * @see #getBannedItems()
	 * @generated
	 */
	EReference getBannedItems_Item();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Magazines <em>Magazines</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Magazines</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Magazines
	 * @generated
	 */
	EClass getMagazines();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.Magazines#getItem <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Magazines#getItem()
	 * @see #getMagazines()
	 * @generated
	 */
	EReference getMagazines_Item();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.books <em>books</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>books</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books
	 * @generated
	 */
	EClass getbooks();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.libray.metamodel.libray.books#getItem <em>Item</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Item</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.books#getItem()
	 * @see #getbooks()
	 * @generated
	 */
	EReference getbooks_Item();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.libray.metamodel.libray.Members <em>Members</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Members</em>'.
	 * @see org.rm2pt.sample.libray.metamodel.libray.Members
	 * @generated
	 */
	EClass getMembers();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	LibrayFactory getLibrayFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl <em>Library</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibraryImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getLibrary()
		 * @generated
		 */
		EClass LIBRARY = eINSTANCE.getLibrary();

		/**
		 * The meta object literal for the '<em><b>Students</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__STUDENTS = eINSTANCE.getLibrary_Students();

		/**
		 * The meta object literal for the '<em><b>Membership</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIBRARY__MEMBERSHIP = eINSTANCE.getLibrary_Membership();

		/**
		 * The meta object literal for the '<em><b>Borrowableitem</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIBRARY__BORROWABLEITEM = eINSTANCE.getLibrary_Borrowableitem();

		/**
		 * The meta object literal for the '<em><b>Librarian</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__LIBRARIAN = eINSTANCE.getLibrary_Librarian();

		/**
		 * The meta object literal for the '<em><b>Administrator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIBRARY__ADMINISTRATOR = eINSTANCE.getLibrary_Administrator();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl <em>Membership</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembership()
		 * @generated
		 */
		EClass MEMBERSHIP = eINSTANCE.getMembership();

		/**
		 * The meta object literal for the '<em><b>Members Details</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEMBERSHIP__MEMBERS_DETAILS = eINSTANCE.getMembership_MembersDetails();

		/**
		 * The meta object literal for the '<em><b>Bannedmembers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMBERSHIP__BANNEDMEMBERS = eINSTANCE.getMembership_Bannedmembers();

		/**
		 * The meta object literal for the '<em><b>Members</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEMBERSHIP__MEMBERS = eINSTANCE.getMembership_Members();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl <em>Item</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.ItemImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getItem()
		 * @generated
		 */
		EClass ITEM = eINSTANCE.getItem();

		/**
		 * The meta object literal for the '<em><b>Booksavailable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__BOOKSAVAILABLE = eINSTANCE.getItem_Booksavailable();

		/**
		 * The meta object literal for the '<em><b>Magazines Availble</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ITEM__MAGAZINES_AVAILBLE = eINSTANCE.getItem_MagazinesAvailble();

		/**
		 * The meta object literal for the '<em><b>Magazines</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEM__MAGAZINES = eINSTANCE.getItem_Magazines();

		/**
		 * The meta object literal for the '<em><b>Books</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEM__BOOKS = eINSTANCE.getItem_Books();

		/**
		 * The meta object literal for the '<em><b>Banneditems</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ITEM__BANNEDITEMS = eINSTANCE.getItem_Banneditems();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl <em>Banned Items</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.BannedItemsImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getBannedItems()
		 * @generated
		 */
		EClass BANNED_ITEMS = eINSTANCE.getBannedItems();

		/**
		 * The meta object literal for the '<em><b>Item</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BANNED_ITEMS__ITEM = eINSTANCE.getBannedItems_Item();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl <em>Magazines</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MagazinesImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMagazines()
		 * @generated
		 */
		EClass MAGAZINES = eINSTANCE.getMagazines();

		/**
		 * The meta object literal for the '<em><b>Item</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MAGAZINES__ITEM = eINSTANCE.getMagazines_Item();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl <em>books</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.booksImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getbooks()
		 * @generated
		 */
		EClass BOOKS = eINSTANCE.getbooks();

		/**
		 * The meta object literal for the '<em><b>Item</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BOOKS__ITEM = eINSTANCE.getbooks_Item();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl <em>Members</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.MembersImpl
		 * @see org.rm2pt.sample.libray.metamodel.libray.impl.LibrayPackageImpl#getMembers()
		 * @generated
		 */
		EClass MEMBERS = eINSTANCE.getMembers();

	}

} //LibrayPackage
