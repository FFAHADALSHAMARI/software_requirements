/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Membership</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getMembersDetails <em>Members Details</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getMembers <em>Members</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership()
 * @model abstract="true"
 * @generated
 */
public interface Membership extends EObject {
	/**
	 * Returns the value of the '<em><b>Members Details</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Members}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Members Details</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership_MembersDetails()
	 * @model containment="true"
	 * @generated
	 */
	EList<Members> getMembersDetails();

	/**
	 * Returns the value of the '<em><b>Bannedmembers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bannedmembers</em>' attribute.
	 * @see #setBannedmembers(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership_Bannedmembers()
	 * @model
	 * @generated
	 */
	String getBannedmembers();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getBannedmembers <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bannedmembers</em>' attribute.
	 * @see #getBannedmembers()
	 * @generated
	 */
	void setBannedmembers(String value);

	/**
	 * Returns the value of the '<em><b>Members</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Members</em>' reference.
	 * @see #setMembers(Members)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembership_Members()
	 * @model derived="true"
	 * @generated
	 */
	Members getMembers();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Membership#getMembers <em>Members</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Members</em>' reference.
	 * @see #getMembers()
	 * @generated
	 */
	void setMembers(Members value);

} // Membership
