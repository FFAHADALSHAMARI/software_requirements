/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Members;
import org.rm2pt.sample.libray.metamodel.libray.Membership;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Membership</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl#getMembersDetails <em>Members Details</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl#getBannedmembers <em>Bannedmembers</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.impl.MembershipImpl#getMembers <em>Members</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class MembershipImpl extends MinimalEObjectImpl.Container implements Membership {
	/**
	 * The cached value of the '{@link #getMembersDetails() <em>Members Details</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMembersDetails()
	 * @generated
	 * @ordered
	 */
	protected EList<Members> membersDetails;

	/**
	 * The default value of the '{@link #getBannedmembers() <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBannedmembers()
	 * @generated
	 * @ordered
	 */
	protected static final String BANNEDMEMBERS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBannedmembers() <em>Bannedmembers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBannedmembers()
	 * @generated
	 * @ordered
	 */
	protected String bannedmembers = BANNEDMEMBERS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMembers() <em>Members</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMembers()
	 * @generated
	 * @ordered
	 */
	protected Members members;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MembershipImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.MEMBERSHIP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Members> getMembersDetails() {
		if (membersDetails == null) {
			membersDetails = new EObjectContainmentEList<Members>(Members.class, this,
					LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS);
		}
		return membersDetails;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBannedmembers() {
		return bannedmembers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBannedmembers(String newBannedmembers) {
		String oldBannedmembers = bannedmembers;
		bannedmembers = newBannedmembers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERSHIP__BANNEDMEMBERS,
					oldBannedmembers, bannedmembers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Members getMembers() {
		if (members != null && members.eIsProxy()) {
			InternalEObject oldMembers = (InternalEObject) members;
			members = (Members) eResolveProxy(oldMembers);
			if (members != oldMembers) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LibrayPackage.MEMBERSHIP__MEMBERS,
							oldMembers, members));
			}
		}
		return members;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Members basicGetMembers() {
		return members;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMembers(Members newMembers) {
		Members oldMembers = members;
		members = newMembers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LibrayPackage.MEMBERSHIP__MEMBERS, oldMembers,
					members));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS:
			return ((InternalEList<?>) getMembersDetails()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS:
			return getMembersDetails();
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			return getBannedmembers();
		case LibrayPackage.MEMBERSHIP__MEMBERS:
			if (resolve)
				return getMembers();
			return basicGetMembers();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS:
			getMembersDetails().clear();
			getMembersDetails().addAll((Collection<? extends Members>) newValue);
			return;
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			setBannedmembers((String) newValue);
			return;
		case LibrayPackage.MEMBERSHIP__MEMBERS:
			setMembers((Members) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS:
			getMembersDetails().clear();
			return;
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			setBannedmembers(BANNEDMEMBERS_EDEFAULT);
			return;
		case LibrayPackage.MEMBERSHIP__MEMBERS:
			setMembers((Members) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LibrayPackage.MEMBERSHIP__MEMBERS_DETAILS:
			return membersDetails != null && !membersDetails.isEmpty();
		case LibrayPackage.MEMBERSHIP__BANNEDMEMBERS:
			return BANNEDMEMBERS_EDEFAULT == null ? bannedmembers != null
					: !BANNEDMEMBERS_EDEFAULT.equals(bannedmembers);
		case LibrayPackage.MEMBERSHIP__MEMBERS:
			return members != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (bannedmembers: ");
		result.append(bannedmembers);
		result.append(')');
		return result.toString();
	}

} //MembershipImpl
