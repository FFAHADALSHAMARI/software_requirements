/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>books</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.books#getItem <em>Item</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks()
 * @model
 * @generated
 */
public interface books extends EObject {
	/**
	 * Returns the value of the '<em><b>Item</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Item}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Item</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getbooks_Item()
	 * @model containment="true"
	 * @generated
	 */
	EList<Item> getItem();

} // books
