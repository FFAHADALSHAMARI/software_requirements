/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage
 * @generated
 */
public interface LibrayFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LibrayFactory eINSTANCE = org.rm2pt.sample.libray.metamodel.libray.impl.LibrayFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Library</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Library</em>'.
	 * @generated
	 */
	Library createLibrary();

	/**
	 * Returns a new object of class '<em>Banned Items</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Banned Items</em>'.
	 * @generated
	 */
	BannedItems createBannedItems();

	/**
	 * Returns a new object of class '<em>Magazines</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Magazines</em>'.
	 * @generated
	 */
	Magazines createMagazines();

	/**
	 * Returns a new object of class '<em>books</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>books</em>'.
	 * @generated
	 */
	books createbooks();

	/**
	 * Returns a new object of class '<em>Members</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Members</em>'.
	 * @generated
	 */
	Members createMembers();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	LibrayPackage getLibrayPackage();

} //LibrayFactory
