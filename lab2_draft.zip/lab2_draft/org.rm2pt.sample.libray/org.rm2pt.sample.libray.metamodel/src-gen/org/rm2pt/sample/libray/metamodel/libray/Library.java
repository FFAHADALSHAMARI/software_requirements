/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Library</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Library#getStudents <em>Students</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Library#getMembership <em>Membership</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Library#getBorrowableitem <em>Borrowableitem</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian <em>Librarian</em>}</li>
 *   <li>{@link org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator <em>Administrator</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary()
 * @model
 * @generated
 */
public interface Library extends EObject {
	/**
	 * Returns the value of the '<em><b>Students</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Students</em>' attribute.
	 * @see #setStudents(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary_Students()
	 * @model
	 * @generated
	 */
	String getStudents();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getStudents <em>Students</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Students</em>' attribute.
	 * @see #getStudents()
	 * @generated
	 */
	void setStudents(String value);

	/**
	 * Returns the value of the '<em><b>Membership</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Membership}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Membership</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary_Membership()
	 * @model containment="true"
	 * @generated
	 */
	EList<Membership> getMembership();

	/**
	 * Returns the value of the '<em><b>Borrowableitem</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.libray.metamodel.libray.Item}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Borrowableitem</em>' containment reference list.
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary_Borrowableitem()
	 * @model containment="true"
	 * @generated
	 */
	EList<Item> getBorrowableitem();

	/**
	 * Returns the value of the '<em><b>Librarian</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Librarian</em>' attribute.
	 * @see #setLibrarian(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary_Librarian()
	 * @model
	 * @generated
	 */
	String getLibrarian();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getLibrarian <em>Librarian</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Librarian</em>' attribute.
	 * @see #getLibrarian()
	 * @generated
	 */
	void setLibrarian(String value);

	/**
	 * Returns the value of the '<em><b>Administrator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Administrator</em>' attribute.
	 * @see #setAdministrator(String)
	 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getLibrary_Administrator()
	 * @model
	 * @generated
	 */
	String getAdministrator();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.libray.metamodel.libray.Library#getAdministrator <em>Administrator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Administrator</em>' attribute.
	 * @see #getAdministrator()
	 * @generated
	 */
	void setAdministrator(String value);

} // Library
