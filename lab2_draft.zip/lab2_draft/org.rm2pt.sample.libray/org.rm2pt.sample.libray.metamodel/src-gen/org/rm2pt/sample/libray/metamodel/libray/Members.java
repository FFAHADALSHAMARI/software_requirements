/**
 */
package org.rm2pt.sample.libray.metamodel.libray;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Members</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.sample.libray.metamodel.libray.LibrayPackage#getMembers()
 * @model
 * @generated
 */
public interface Members extends EObject {
} // Members
