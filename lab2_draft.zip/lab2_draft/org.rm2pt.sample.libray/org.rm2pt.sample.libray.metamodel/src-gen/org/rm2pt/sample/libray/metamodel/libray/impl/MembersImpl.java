/**
 */
package org.rm2pt.sample.libray.metamodel.libray.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.rm2pt.sample.libray.metamodel.libray.LibrayPackage;
import org.rm2pt.sample.libray.metamodel.libray.Members;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Members</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MembersImpl extends MinimalEObjectImpl.Container implements Members {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MembersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LibrayPackage.Literals.MEMBERS;
	}

} //MembersImpl
